<?php
	/*
	Plugin Name: 	Quadrum Extended
	Plugin URI: 	http://www.orange-themes.com/
	Description: 	Quadrum shortcodes & galleries
	Version: 		1.0.0
	Author: 		Orange Themes
	Author URI: 	http://www.orange-themes.com/
	Domain Path:    /languages
	Text Domain:	quadrum-theme
	License:		GPL-2.0+
	License URI:	http://www.gnu.org/licenses/gpl-2.0.txt
	*/

function quadrum_extended() {
	return true;
}

require_once( plugin_dir_path(__FILE__).'shortcodes/init.php' );
add_action('init', 'quadrum_create_gallery');

if (!defined('OT_POST_GALLERY')) {
	//POST TYPES
	define("OT_POST_GALLERY","gallery");	
}

function quadrum_create_gallery() {
		
	$labels = array(
    'name' => _x('Gallery', 'quadrum menu', 'quadrum-theme'),
    'singular_name' => _x('Gallery Menu', 'quadrum menu', 'quadrum-theme'),
    'add_new' => _x('Add New', 'quadrum menu', 'quadrum-theme'),
    'add_new_item' => esc_html__('Add New Item','quadrum-theme'),
    'edit_item' => esc_html__('Edit Item','quadrum-theme'),
    'new_item' => esc_html__('New Gallery Item','quadrum-theme'),
    'view_item' => esc_html__('View Item','quadrum-theme'),
    'search_items' => esc_html__('Search Gallery Items','quadrum-theme'),
    'not_found' =>  esc_html__('No gallery items found','quadrum-theme'),
    'not_found_in_trash' => esc_html__('No gallery items found in Trash','quadrum-theme'), 
    'parent_item_colon' => ''
	);
  
	register_taxonomy(OT_POST_GALLERY."-cat", 
					    	array("Gallery Categories"), 
					    	array(	"hierarchical" => true, 
					    			"label" => "Gallery Categories", 
					    			"singular_label" => "Gallery Categories", 
					    			"rewrite" => true,
					    			"query_var" => true
					    		));  
		
		register_post_type( OT_POST_GALLERY,
		array( 'labels' => $labels,
	         'public' => true,  
	         'show_ui' => true,  
	         'capability_type' => 'post',  
	         'hierarchical' => false,  
			 'taxonomies' => array(OT_POST_GALLERY.'-cat'),
	         'supports' => array('title', 'editor', 'thumbnail', 'comments', 'page-attributes', 'excerpt') ) );

}